import { MoodTracker } from "@/components/MoodTracker";
import { AIChat } from "@/components/AIChat";
import { BreathingExercise } from "@/components/BreathingExercise";
import { WellnessTip } from "@/components/WellnessTip";
import { MusicPlayer } from "@/components/MusicPlayer";
import { GratitudeJournal } from "@/components/GratitudeJournal";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/50 to-accent/50">
      <div className="container py-8 px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12 animate-fade-up">
          <h1 className="text-4xl font-bold text-primary mb-4">Manomithra</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A safe space for your mental health journey, with AI-powered support and tools to help you thrive.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="space-y-8">
            <MoodTracker />
            <WellnessTip />
            <GratitudeJournal />
          </div>
          <div className="space-y-8">
            <AIChat />
            <BreathingExercise />
          </div>
        </div>
      </div>
      <MusicPlayer />
    </div>
  );
};

export default Index;