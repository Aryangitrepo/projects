import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart, Sun, Cloud, CloudRain, CloudLightning } from "lucide-react";

const moods = [
  { icon: Heart, label: "Great", color: "text-rose-500" },
  { icon: Sun, label: "Good", color: "text-yellow-500" },
  { icon: Cloud, label: "Okay", color: "text-blue-400" },
  { icon: CloudRain, label: "Down", color: "text-gray-500" },
  { icon: CloudLightning, label: "Rough", color: "text-purple-500" },
];

export const MoodTracker = () => {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);

  return (
    <div className="p-6 rounded-2xl bg-white shadow-sm animate-fade-in">
      <h3 className="text-lg font-semibold mb-4">How are you feeling today?</h3>
      <div className="flex flex-wrap gap-4 justify-center">
        {moods.map((mood, index) => (
          <Button
            key={mood.label}
            variant="outline"
            className={`flex flex-col items-center p-4 hover:bg-accent transition-all duration-300 ${
              selectedMood === index ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => setSelectedMood(index)}
          >
            <mood.icon className={`w-8 h-8 ${mood.color}`} />
            <span className="mt-2 text-sm">{mood.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
};