import { useState, useEffect } from "react";

export const BreathingExercise = () => {
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    if (!isActive) return;

    const cycle = async () => {
      setPhase("inhale");
      await new Promise((resolve) => setTimeout(resolve, 4000));
      setPhase("hold");
      await new Promise((resolve) => setTimeout(resolve, 4000));
      setPhase("exhale");
      await new Promise((resolve) => setTimeout(resolve, 4000));
    };

    const interval = setInterval(cycle, 12000);
    cycle();

    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <div className="p-6 rounded-2xl bg-white shadow-sm text-center animate-fade-in">
      <h3 className="text-lg font-semibold mb-4">Breathing Exercise</h3>
      <div className="relative w-32 h-32 mx-auto mb-4">
        <div
          className={`absolute inset-0 rounded-full bg-primary/20 transition-transform duration-4000 ${
            isActive && "animate-breathe"
          }`}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-lg font-medium text-primary">
            {phase === "inhale" ? "Breathe In" : phase === "hold" ? "Hold" : "Breathe Out"}
          </span>
        </div>
      </div>
      <button
        onClick={() => setIsActive(!isActive)}
        className="px-6 py-2 rounded-full bg-primary text-white hover:bg-primary/90 transition-colors"
      >
        {isActive ? "Stop" : "Start"} Exercise
      </button>
    </div>
  );
};