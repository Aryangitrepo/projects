import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Heart, Plus } from "lucide-react";
import { useToast } from "./ui/use-toast";

export const GratitudeJournal = () => {
  const [entries, setEntries] = useState<string[]>([]);
  const [newEntry, setNewEntry] = useState("");
  const { toast } = useToast();

  const addEntry = () => {
    if (newEntry.trim()) {
      setEntries([...entries, newEntry.trim()]);
      setNewEntry("");
      toast({
        title: "Gratitude noted ✨",
        description: "Your moment of gratitude has been saved.",
      });
    }
  };

  return (
    <Card className="p-6 bg-white shadow-sm animate-fade-in">
      <div className="flex items-center gap-2 mb-4">
        <Heart className="w-5 h-5 text-primary animate-pulse" />
        <h3 className="text-lg font-semibold">Gratitude Journal</h3>
      </div>
      
      <div className="space-y-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={newEntry}
            onChange={(e) => setNewEntry(e.target.value)}
            placeholder="What are you grateful for today?"
            className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
            onKeyPress={(e) => e.key === "Enter" && addEntry()}
          />
          <Button
            size="icon"
            variant="outline"
            onClick={addEntry}
            className="shrink-0"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-2">
          {entries.map((entry, index) => (
            <div
              key={index}
              className="p-3 bg-accent/50 rounded-lg text-sm animate-fade-up"
            >
              {entry}
            </div>
          ))}
          {entries.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-2">
              Start your gratitude journey by adding your first entry...
            </p>
          )}
        </div>
      </div>
    </Card>
  );
};