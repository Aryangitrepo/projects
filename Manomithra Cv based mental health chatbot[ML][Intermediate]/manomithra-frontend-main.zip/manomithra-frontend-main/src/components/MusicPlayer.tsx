import { useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";

export const MusicPlayer = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio] = useState(new Audio("/meditation-music.mp3"));

  const togglePlay = () => {
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
      audio.loop = true;
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 animate-fade-in">
      <Button
        variant="outline"
        size="icon"
        className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90 transition-all"
        onClick={togglePlay}
      >
        {isPlaying ? (
          <Volume2 className="h-4 w-4 text-primary" />
        ) : (
          <VolumeX className="h-4 w-4 text-primary" />
        )}
      </Button>
    </div>
  );
};