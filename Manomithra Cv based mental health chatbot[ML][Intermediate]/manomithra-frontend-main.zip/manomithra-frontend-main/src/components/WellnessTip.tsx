import { Lightbulb } from "lucide-react";

const tips = [
  "Take a moment to appreciate three things you're grateful for today.",
  "Remember that it's okay to take breaks and rest when you need to.",
  "Small steps forward are still progress. Celebrate your victories, no matter how small.",
  "Your feelings are valid, and it's okay to feel them fully.",
];

export const WellnessTip = () => {
  const randomTip = tips[Math.floor(Math.random() * tips.length)];

  return (
    <div className="p-6 rounded-2xl bg-white shadow-sm animate-fade-in">
      <div className="flex items-center gap-2 mb-3">
        <Lightbulb className="w-5 h-5 text-yellow-500" />
        <h3 className="text-lg font-semibold">Daily Wellness Tip</h3>
      </div>
      <p className="text-muted-foreground leading-relaxed">{randomTip}</p>
    </div>
  );
};