import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Shield, Globe, Mail, Upload, ChevronLeft, ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';
import shieldLogo from '@/assets/shield-logo.png';

type ScreenType = 'url' | 'email' | 'file';

interface CheckResult {
  status: 'safe' | 'suspicious' | 'dangerous' | null;
  message: string;
}

const ArtemisShield = () => {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('url');
  const [urlInput, setUrlInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [fileInput, setFileInput] = useState<File | null>(null);
  const [urlResult, setUrlResult] = useState<CheckResult>({ status: null, message: '' });
  const [emailResult, setEmailResult] = useState<CheckResult>({ status: null, message: '' });
  const [fileResult, setFileResult] = useState<CheckResult>({ status: null, message: '' });

  const screens = [
    { id: 'url' as ScreenType, title: 'URL Scanner', icon: Globe, description: 'Check if a website link is safe to visit' },
    { id: 'email' as ScreenType, title: 'Email/SMS Checker', icon: Mail, description: 'Verify the legitimacy of emails and text messages' },
    { id: 'file' as ScreenType, title: 'File Analyzer', icon: Upload, description: 'Scan files for malware and DNS poisoning' }
  ];

  const getCurrentScreenIndex = () => screens.findIndex(screen => screen.id === currentScreen);

  const navigateScreen = (direction: 'prev' | 'next') => {
    const currentIndex = getCurrentScreenIndex();
    let newIndex;
    
    if (direction === 'prev') {
      newIndex = currentIndex > 0 ? currentIndex - 1 : screens.length - 1;
    } else {
      newIndex = currentIndex < screens.length - 1 ? currentIndex + 1 : 0;
    }
    
    setCurrentScreen(screens[newIndex].id);
  };

  const simulateCheck = (type: ScreenType, input: string | File | null): CheckResult => {
    // Simple simulation logic for demo purposes
    if (!input) return { status: null, message: 'Please provide input to check' };
    
    const random = Math.random();
    if (random < 0.7) {
      return { status: 'safe', message: 'This appears to be legitimate and safe.' };
    } else if (random < 0.9) {
      return { status: 'suspicious', message: 'This shows some suspicious patterns. Exercise caution.' };
    } else {
      return { status: 'dangerous', message: 'Warning: This appears to be malicious. Do not proceed.' };
    }
  };

  const handleUrlCheck = () => {
    const result = simulateCheck('url', urlInput);
    setUrlResult(result);
  };

  const handleEmailCheck = () => {
    const result = simulateCheck('email', emailInput);
    setEmailResult(result);
  };

  const handleFileCheck = () => {
    const result = simulateCheck('file', fileInput);
    setFileResult(result);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFileInput(file);
    setFileResult({ status: null, message: '' });
  };

  const getResultIcon = (status: CheckResult['status']) => {
    switch (status) {
      case 'safe': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'suspicious': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'dangerous': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return null;
    }
  };

  const getResultColor = (status: CheckResult['status']) => {
    switch (status) {
      case 'safe': return 'text-green-600 bg-green-50 border-green-200';
      case 'suspicious': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      case 'dangerous': return 'text-red-600 bg-red-50 border-red-200';
      default: return '';
    }
  };

  const currentScreenData = screens.find(screen => screen.id === currentScreen);
  const CurrentIcon = currentScreenData?.icon || Globe;

  return (
    <div className="min-h-screen bg-gradient-aurora relative overflow-hidden">
      {/* Floating background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyber-primary/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyber-accent/15 rounded-full blur-3xl animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-cyber-secondary/10 rounded-full blur-3xl animate-float" style={{animationDelay: '4s'}}></div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header with glassmorphism */}
        <div className="text-center mb-12 animate-fade-up">
          <div className="flex justify-center items-center gap-4 mb-6">
            <div className="relative">
              <img 
                src={shieldLogo} 
                alt="ArtemisShield Logo" 
                className="w-16 h-16 animate-glow relative z-10"
              />
              <div className="absolute inset-0 w-16 h-16 bg-cyber-accent/30 rounded-full blur-lg animate-pulse-soft"></div>
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-white via-cyber-soft to-white bg-clip-text text-transparent drop-shadow-lg">
              ArtemisShield
            </h1>
          </div>
          
          {/* Glassmorphic description container */}
          <div className="max-w-4xl mx-auto backdrop-blur-glass bg-gradient-glass border border-white/20 rounded-2xl p-8 shadow-glass">
            <p className="text-lg text-white/90 leading-relaxed">
              Your powerful platform to fight scams and online frauds. ArtemisShield serves as your digital shield against hackers who use phishing and social engineering techniques to obtain data from unsuspecting users. Stay protected, stay informed, stay secure.
            </p>
          </div>
        </div>

        {/* Enhanced Navigation Pills with glassmorphism */}
        <div className="flex justify-center mb-8">
          <div className="backdrop-blur-glass bg-white/10 border border-white/20 rounded-2xl p-2 shadow-glass">
            <div className="flex gap-2">
              {screens.map((screen, index) => (
                <button
                  key={screen.id}
                  onClick={() => setCurrentScreen(screen.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all duration-500 ${
                    currentScreen === screen.id
                      ? 'bg-white/90 text-cyber-primary shadow-medium backdrop-blur-sm transform scale-105'
                      : 'text-white/80 hover:bg-white/20 hover:text-white backdrop-blur-sm'
                  }`}
                >
                  <screen.icon className="w-4 h-4" />
                  <span className="font-medium">{screen.title}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Enhanced Main Scanner Card with glassmorphism */}
        <div className="max-w-4xl mx-auto">
          <div className="backdrop-blur-glass bg-gradient-card-soft border border-white/30 rounded-3xl shadow-large overflow-hidden">
            <div className="text-center p-8 border-b border-white/20">
              <div className="flex justify-between items-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigateScreen('prev')}
                  className="text-muted-foreground hover:text-primary hover:bg-white/20 backdrop-blur-sm rounded-full transition-all duration-300"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                
                <div className="flex flex-col items-center">
                  <div className="relative mb-4">
                    <div className="bg-gradient-aurora p-4 rounded-2xl shadow-glass backdrop-blur-sm border border-white/30">
                      <CurrentIcon className="w-8 h-8 text-white drop-shadow-lg" />
                    </div>
                    <div className="absolute inset-0 bg-cyber-accent/30 rounded-2xl blur-lg animate-pulse-soft"></div>
                  </div>
                  <h2 className="text-2xl font-bold text-cyber-muted mb-2">
                    {currentScreenData?.title}
                  </h2>
                  <p className="text-lg text-muted-foreground">
                    {currentScreenData?.description}
                  </p>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigateScreen('next')}
                  className="text-muted-foreground hover:text-primary hover:bg-white/20 backdrop-blur-sm rounded-full transition-all duration-300"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="p-8 space-y-6">
              {/* URL Scanner */}
              {currentScreen === 'url' && (
                <div className="space-y-4 animate-slide-in">
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-cyber-muted">Enter URL to check:</label>
                    <div className="flex gap-3">
                      <Input
                        type="url"
                        placeholder="https://example.com"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        className="flex-1 backdrop-blur-sm bg-white/50 border-2 border-white/30 focus:border-cyber-primary/50 focus:ring-2 focus:ring-cyber-primary/20 rounded-xl transition-all duration-300"
                      />
                      <Button 
                        onClick={handleUrlCheck}
                        className="bg-gradient-aurora hover:opacity-90 text-white px-8 rounded-xl shadow-medium border border-white/30 backdrop-blur-sm transition-all duration-300 hover:scale-105"
                        disabled={!urlInput.trim()}
                      >
                        Scan URL
                      </Button>
                    </div>
                  </div>
                  
                  {urlResult.status && (
                    <div className={`p-6 rounded-2xl border-2 flex items-start gap-4 backdrop-blur-sm transition-all duration-500 ${getResultColor(urlResult.status)}`}>
                      <div className="flex-shrink-0">
                        {getResultIcon(urlResult.status)}
                      </div>
                      <div>
                        <p className="font-semibold text-lg mb-1">Security Analysis Complete</p>
                        <p className="opacity-90">{urlResult.message}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Email/SMS Scanner */}
              {currentScreen === 'email' && (
                <div className="space-y-4 animate-slide-in">
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-cyber-muted">Paste email or SMS content:</label>
                    <Textarea
                      placeholder="Paste the suspicious email content or SMS message here..."
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="min-h-32 backdrop-blur-sm bg-white/50 border-2 border-white/30 focus:border-cyber-primary/50 focus:ring-2 focus:ring-cyber-primary/20 rounded-xl resize-none transition-all duration-300"
                    />
                    <Button 
                      onClick={handleEmailCheck}
                      className="bg-gradient-aurora hover:opacity-90 text-white px-8 rounded-xl shadow-medium border border-white/30 backdrop-blur-sm transition-all duration-300 hover:scale-105"
                      disabled={!emailInput.trim()}
                    >
                      Analyze Message
                    </Button>
                  </div>
                  
                  {emailResult.status && (
                    <div className={`p-6 rounded-2xl border-2 flex items-start gap-4 backdrop-blur-sm transition-all duration-500 ${getResultColor(emailResult.status)}`}>
                      <div className="flex-shrink-0">
                        {getResultIcon(emailResult.status)}
                      </div>
                      <div>
                        <p className="font-semibold text-lg mb-1">Message Analysis Complete</p>
                        <p className="opacity-90">{emailResult.message}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* File Scanner */}
              {currentScreen === 'file' && (
                <div className="space-y-4 animate-slide-in">
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-cyber-muted">Upload file to scan:</label>
                    <div className="border-2 border-dashed border-white/40 rounded-2xl p-12 text-center hover:border-cyber-primary/50 transition-all duration-300 backdrop-blur-sm bg-white/20">
                      <Upload className="w-16 h-16 text-cyber-primary/70 mx-auto mb-6" />
                      <div className="space-y-3">
                        <input
                          type="file"
                          onChange={handleFileChange}
                          className="hidden"
                          id="file-upload"
                          accept=".pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.exe,.apk"
                        />
                        <label 
                          htmlFor="file-upload"
                          className="inline-block cursor-pointer text-cyber-primary hover:text-cyber-accent font-semibold text-lg transition-colors duration-300"
                        >
                          Click to upload file
                        </label>
                        <p className="text-sm text-muted-foreground">
                          Supports PDF, DOC, XLS, ZIP, EXE, APK files
                        </p>
                        {fileInput && (
                          <div className="mt-4 p-3 bg-white/30 rounded-xl backdrop-blur-sm">
                            <p className="text-sm font-medium text-cyber-muted">
                              Selected: {fileInput.name}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                    {fileInput && (
                      <Button 
                        onClick={handleFileCheck}
                        className="bg-gradient-aurora hover:opacity-90 text-white px-8 rounded-xl shadow-medium border border-white/30 backdrop-blur-sm transition-all duration-300 hover:scale-105"
                      >
                        Scan File
                      </Button>
                    )}
                  </div>
                  
                  {fileResult.status && (
                    <div className={`p-6 rounded-2xl border-2 flex items-start gap-4 backdrop-blur-sm transition-all duration-500 ${getResultColor(fileResult.status)}`}>
                      <div className="flex-shrink-0">
                        {getResultIcon(fileResult.status)}
                      </div>
                      <div>
                        <p className="font-semibold text-lg mb-1">File Analysis Complete</p>
                        <p className="opacity-90">{fileResult.message}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Enhanced Bottom Shield */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-3 backdrop-blur-sm bg-white/10 px-6 py-3 rounded-full border border-white/20 shadow-glass">
            <Shield className="w-5 h-5 text-white/90" />
            <span className="text-white/90 font-medium">Protected by ArtemisShield Security Platform</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArtemisShield;