import ArtemisShield from '@/components/ArtemisShield';

const Index = () => {
  return <ArtemisShield />;
};

export default Index;
